import * as angular from 'angular';

export class contactcontroller {
    static $inject = ['$scope'];
    message: string;
  
    constructor() {
      // Controller logic for About
      this.message = ''
    }
  }
  