interface IDataScope extends angular.IScope {
    data: any; 
}
